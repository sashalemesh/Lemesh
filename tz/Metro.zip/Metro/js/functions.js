$(document).ready(function(){

if( jQuery.isFunction(jQuery.fn.inFieldLabels) ){
$("p.label label").inFieldLabels({fadeOpacity:0});
}
	
});