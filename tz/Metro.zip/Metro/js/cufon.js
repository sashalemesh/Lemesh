
function cufon_init(){
    Cufon.replace('.title-make_a_reservation_2', {fontFamily: 'Robust ICG', textShadow: '#474342 -1px -1px', hover: true});
}
cufon_init();