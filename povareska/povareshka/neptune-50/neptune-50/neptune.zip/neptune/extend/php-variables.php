<?php
// Insert your custom vars here and back up this file before a theme update,
// so you can override color scheme variables and not lose your changes after theme update

// e.g
// $scheme_vars[ 'bodyBackgroundColor' ]         = '#f0f3f5';

?>