<div class="not-found-icon"><i class="os-icon os-icon-frown-o"></i></div>
<h1 class='page-title'><?php esc_html_e('No results found', 'osetin'); ?></h1>
<p><?php esc_html_e('Make sure the query is spelled correctly and try again:', 'osetin'); ?></p>