<?php
/**
 * Admin View: Notice - Theme Support
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="error osetin-theme-update-message">
	<p>
    License is not active:<strong> connection error please try again later</strong>    
  </p>
</div>
