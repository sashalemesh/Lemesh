<?php
/**
 * Admin View: Notice - Theme Support
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

?>
<div class="error osetin-theme-update-message">
  <p>
     We can not process your request. Reason: Please provide Theme Name, Site Name and Purchase Code.   
  </p>
</div>