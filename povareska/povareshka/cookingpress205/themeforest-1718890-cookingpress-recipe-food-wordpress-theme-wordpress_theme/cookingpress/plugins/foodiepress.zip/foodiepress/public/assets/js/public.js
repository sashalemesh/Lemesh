(function ( $ ) {
	"use strict";

	$(function () {

        $('.purerecipe .instructions ul li, .purerecipe ul.ingredients li').click(function(){
            $(this).toggleClass('active')
        })

		// Place your public-facing JavaScript here

	});

}(jQuery));