<?php
/**
 * FoodiePress.
 *
 * @package   FoodiePress
 * @author    purethemes
 * @license   ThemeForest
 * @copyright 2014 Purethemes.net
 */


class FoodiePressTransferTags {
    /**
     * Instance of this class.
     *
     * @since    1.0.0
     *
     * @var      object
     */
    protected static $instance = null;
    /**
     * Slug of the plugin screen.
     *
     * @since    1.0.0
     *
     * @var      string
     */
    protected $plugin_screen_hook_suffix = null;
    private function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_admin_menu' ) );
    }

    public static function get_instance() {

        /*
         * @TODO :
         *
         * - Uncomment following lines if the admin class should only be available for super admins
         */
        /* if( ! is_super_admin() ) {
            return;
        } */

        // If the single instance hasn't been set, set it now.
        if ( null == self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Register the administration menu for this plugin into the WordPress Dashboard menu.
     *
     * @since    1.0.0
     */
    public function add_plugin_admin_menu() {

        /*
         * Add a settings page for this plugin to the Settings menu.
         *
         * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
         *
         *        Administration Menus: http://codex.wordpress.org/Administration_Menus
         *
         * @TODO:
         *
         * - Change 'Page Title' to the title of your plugin admin page
         * - Change 'Menu Text' to the text for menu item for the plugin settings page
         * - Change 'manage_options' to the capability you see fit
         *   For reference: http://codex.wordpress.org/Roles_and_Capabilities
         */
        $this->options = get_option( 'force_shortcode_option' );

        $this->plugin_screen_hook_suffix = add_submenu_page(
            'foodiepress', //$parent_slug,
            'FoodiePress',//$page_title,
            'Tags Converter',//$menu_title,
            'manage_options',//$capability,
            'tags-converter',//$menu_slug,
            array( $this, 'display_plugin_admin_page' )//$function
            );
    }
    /**
         * Render the settings page for this plugin.
         *
         * @since    1.0.0
         */
    public function display_plugin_admin_page() { ?>
        Taka tam strona;
    <?php }
}