<?php
include "config1.php";
$name2 = trim(strip_tags($_REQUEST['name2']));
$name3 = trim(strip_tags($_REQUEST['name3']));
    //Редактируем пользователя
    $sql_select2 = "UPDATE user SET username='$name3' WHERE username='$name2'";
    $result = mysql_query($sql_select2);
    //Выводим добавленного пользователя
    $sql_select = "SELECT * FROM user WHERE username='$name3'";
    $result2 = mysql_query($sql_select);
    $row2 = mysql_fetch_array($result2);

if($row2) {
    printf("<p>Пользователь: " .$row2['username'] . " " .$row2['userid'] ."</p>" );
} else{
    echo "Пользователя с таким именем в базе нет<br/><br/>";
}
