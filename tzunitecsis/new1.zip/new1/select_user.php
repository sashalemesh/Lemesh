<?php
include "config1.php";
$row_per_page = 10;
//$first_name = trim($_REQUEST['name']);
$first_name = trim(strip_tags($_REQUEST['name1']));
    $sql_select = "SELECT * FROM user WHERE username='$first_name'";
$result = mysql_query($sql_select);
$row = mysql_fetch_array($result);

$all_users = mysql_query("SELECT * FROM user ORDER BY username");
$i = 0;
while ( $user[] = mysql_fetch_array($all_users) ){
    if($user[$i]['username'] == $row['username'])
        break;
    $i++;
}
$user_row_number = count($user);
$user_page = intval(($user_row_number - 1) / $row_per_page) + 1;

if($row) {
    echo '<a href="index.php?page='.$user_page.'&id='.$row['userid'].'">';
    printf("<p>Пользователь: " .$row['username'] . " " .$row['userid'] ."</p>" );
    echo '</a>';
} else{
echo "Пользователя с таким именем в базе нет<br/><br/>";
}

?> 
