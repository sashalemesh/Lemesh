<?php
include "config1.php";

//Выводим последнего добавленого пользователя
$sql_select = "SELECT * FROM user ORDER BY userid DESC LIMIT 1";
$result2 = mysql_query($sql_select);
$row2 = mysql_fetch_array($result2);
if($row2) {
    printf("<p>Пользователь: " .$row2['username'] . " " .$row2['userid'] ."</p>" );
} else{
    echo "Пользователя с таким именем в базе нет<br/><br/>";
}


//// Извлекаем из URL текущую страницу
//$page = $_GET['page'];
//// Определяем начало сообщений для текущей страницы
//$page = intval($page);
//while ( $postrow[] = mysql_fetch_array($result2));
////Пагинация
////if($page)$page =  '<a href=index.php?page=. ($page) .'>>'</a>';
// //Проверяем нужны ли стрелки назад
//if ($page != 1) $pervpage = '<a href=index.php?page=1><<</a>
//                               <a href=index.php?page='. ($page - 1) .'><</a> ';
//// Проверяем нужны ли стрелки вперед
//if ($page != $total) $nextpage = ' <a href=index.php?page='. ($page + 1) .'>></a>
//                                   <a href=index.php?page=' .$total. '>>></a>';
//
//// Находим две ближайшие станицы с обоих краев, если они есть
//if($page - 2 > 0) $page2left = ' <a href=index.php?page='. ($page - 2) .'>'. ($page - 2) .'</a> | ';
//if($page - 1 > 0) $page1left = '<a href=index.php?page='. ($page - 1) .'>'. ($page - 1) .'</a> | ';
//if($page + 2 <= $total) $page2right = ' | <a href=index.php?page='. ($page + 2) .'>'. ($page + 2) .'</a>';
//if($page + 1 <= $total) $page1right = ' | <a href=index.php?page='. ($page + 1) .'>'. ($page + 1) .'</a>';
//
// //Вывод меню
//$paginate1 = $pervpage.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$nextpage;
//$paginate1=$page;