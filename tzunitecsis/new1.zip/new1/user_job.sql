-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 18 2017 г., 23:13
-- Версия сервера: 5.5.50
-- Версия PHP: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `user_job`
--

-- --------------------------------------------------------

--
-- Структура таблицы `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL,
  `text` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=359 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`userid`, `username`) VALUES
(1, 'Bob'),
(2, 'Garik'),
(3, 'Kventin'),
(4, 'Kevin'),
(5, 'David'),
(6, 'Genri'),
(7, 'Dima'),
(8, 'Dima'),
(9, 'Valia'),
(26, 'Lukas'),
(27, 'Lukas'),
(28, 'Lukas'),
(29, 'Lukas'),
(30, 'Lukas'),
(31, 'Lukas'),
(34, 'Lukas'),
(50, 'grena'),
(51, 'grena'),
(52, 'grena'),
(53, 'grena'),
(54, 'grena'),
(55, 'grena'),
(56, 'grena'),
(57, 'Kelvin'),
(58, 'Anna'),
(59, 'Den'),
(72, 'Akim'),
(73, 'Akim'),
(79, 'abb'),
(80, 'abb'),
(87, 'Andru'),
(88, 'Kat'),
(89, 'Alisa'),
(119, 'Kat'),
(120, 'Kat'),
(126, 'Tomas'),
(127, 'Jerry'),
(128, 'Rate'),
(129, 'Aaaron'),
(130, 'Akim'),
(131, 'Albert'),
(132, 'Abiaty'),
(133, 'Abiaty'),
(134, 'Abiaty'),
(135, 'Abiaty'),
(136, 'Zuk'),
(137, 'Zuk'),
(138, 'Zuk'),
(139, 'wer'),
(140, 'Lili'),
(141, 'qsqdq'),
(142, 'Glen'),
(150, 'erfg'),
(151, 'erfg'),
(152, 'erfg'),
(153, 'e3e'),
(154, 'gt4g4'),
(155, 'gt4g4'),
(156, 'dwdqd'),
(157, 'dD'),
(158, 'XX'),
(159, 'DFG'),
(160, 'DFG'),
(163, 'asas'),
(164, 'asas'),
(165, 'asas'),
(166, 'asas'),
(167, 'dqdqdq'),
(168, 'dqdqdq'),
(169, 'dqdqdq'),
(173, 'ssss'),
(202, 'ssss'),
(203, 'ssss'),
(204, 'ssss'),
(225, 'wer'),
(226, 'add'),
(227, 'qsdr'),
(228, 'qsdr'),
(229, 'GAH'),
(230, 'ad'),
(231, 'sdf'),
(232, 'sdf'),
(233, 'cfg'),
(234, 'cfg'),
(235, 'cfg'),
(236, 'cfgq'),
(237, 'cfgq'),
(244, 'sss'),
(246, 'wer'),
(247, 'asw'),
(248, 'ssss'),
(250, 'rew'),
(251, 'ss'),
(254, 'asd'),
(255, 'wd'),
(260, 'qwe'),
(261, 'qsa'),
(262, 'sqdq'),
(264, 'екеее'),
(265, 'Kostia'),
(266, 'ggwww'),
(268, 'wwgwgwg'),
(269, 'o87o8'),
(270, 'o97oo'),
(271, 'o97oo'),
(272, 'dwd'),
(273, 'wcww'),
(274, 'dqdq'),
(275, 'qdqdqdq'),
(276, 'sqqsqs'),
(277, 'qsqs'),
(279, 'ser'),
(280, 'xs'),
(282, 'TOm'),
(290, 'фйы'),
(291, 'sss'),
(298, 'scsc'),
(301, 'dss'),
(302, 'abiati'),
(303, 'sdq'),
(304, 'errr'),
(305, 'tre'),
(306, 'ewr'),
(307, 'ewr'),
(308, 'rree'),
(309, 'wewer'),
(310, 'rttyy'),
(311, 'ddwdd'),
(312, 'sdqd'),
(313, 'dwdwd'),
(314, 'ssssdddd'),
(315, 'qdqdd'),
(316, 'yrty'),
(317, 'dwwf'),
(318, 'dqdd'),
(319, 'df2f2f'),
(320, 'ssssssss'),
(321, 'aasdd'),
(322, 'ssss'),
(323, 'qqqwww'),
(324, 'xaxa'),
(325, 'sqsqs'),
(326, 'sqsqs'),
(327, 'sqsq'),
(328, 'xaxax'),
(329, 'dqdqd'),
(330, 'ssssssdddd'),
(331, 'ddqd'),
(332, 'sqsq'),
(333, 'gnff'),
(334, 'sdf'),
(335, 'dfff'),
(336, 'sss'),
(337, 'qqqq'),
(338, 'tre'),
(339, 'asd'),
(340, 'adqd'),
(341, 'qss'),
(342, 'qq'),
(343, 'dabdb'),
(344, 'aaaaa'),
(345, 'qdq'),
(346, 'dqdq'),
(347, 'asdd'),
(348, 'к2к2к'),
(349, 'qqdqdq'),
(350, 'qsq'),
(351, 'asd'),
(352, 'qsd'),
(353, 'ss'),
(354, 'sqsqssq'),
(355, 'dfg'),
(356, 'qdd'),
(357, 'sssss'),
(358, 'mkokjibiih');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=359;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
